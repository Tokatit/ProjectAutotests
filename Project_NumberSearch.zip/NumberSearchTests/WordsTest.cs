﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NumberSearch;
using System;

namespace NumberSearchTests
{
    [TestClass()]
    public class WordsTest
    {
        [TestMethod()]
        public void Words_OneSymbol_OneWord()
        {
            string input = "Ж";
            string[] strForSearch = { "А111ЖА", "А111АА" };

            Words w = new Words(strForSearch, input);

            string expectedResult = "А111ЖА";
            int expectedQuantity = 1;

            string actualResult = w.Result;
            int actualQuantity = w.Quantity;

            Assert.AreEqual(expectedResult, actualResult, "Вывод слов на дисплей ");
            Assert.AreEqual(expectedQuantity, actualQuantity, "Количество слов ");
        }

        [TestMethod()]
        public void Words_OneSymbol_ThreeWords()
        {
            string input = "А";
            string[] strForSearch = { "А111ЖА", "А121АА", "Л000ЖА", "Л765ЖK" };
            string[] expected = { "А111ЖА", "А121АА", "Л000ЖА" };

            Words w = new Words(strForSearch, input);

            string expectedResult = string.Join(Environment.NewLine, expected);
            int expectedQuantity = 3;

            string actualResult = w.Result;
            int actualQuantity = w.Quantity;

            Assert.AreEqual(expectedResult, actualResult, "Вывод слов на дисплей ");
            Assert.AreEqual(expectedQuantity, actualQuantity, "Количество слов ");
        }

        [TestMethod()]
        public void Words_FourSymbol_ZeroWords()
        {
            string input = "А123";
            string[] strForSearch = { "А111ЖА", "А121АА", "Л000ЖА", "Л765ЖK" };

            Words w = new Words(strForSearch, input);

            string expectedResult = "";
            int expectedQuantity = 0;

            string actualResult = w.Result;
            int actualQuantity = w.Quantity;

            Assert.AreEqual(expectedResult, actualResult, "Вывод слов на дисплей ");
            Assert.AreEqual(expectedQuantity, actualQuantity, "Количество слов ");
        }

        [TestMethod()]
        public void Words_SymbolWithSpace_NotWord()
        {
            string input = " А1";
            string[] strForSearch = { "А111ЖА", "А121АА", "Л000ЖА", "Л765ЖK" };

            Words w = new Words(strForSearch, input);

            string expectedResult = "";
            int expectedQuantity = 0;

            string actualResult = w.Result;
            int actualQuantity = w.Quantity;

            Assert.AreEqual(expectedResult, actualResult, "Вывод слов на дисплей ");
            Assert.AreEqual(expectedQuantity, actualQuantity, "Количество слов ");
        }

        [TestMethod()]
        public void Words_SymbolEng_OneWord()
        {
            string input = "D";
            string[] strForSearch = { "А111ПО", "G121DD", "Л000ЖА", "Л765ЖK" };

            Words w = new Words(strForSearch, input);

            string expectedResult = "G121DD";
            int expectedQuantity = 1;

            string actualResult = w.Result;
            int actualQuantity = w.Quantity;

            Assert.AreEqual(expectedResult, actualResult, "Вывод слов на дисплей ");
            Assert.AreEqual(expectedQuantity, actualQuantity, "Количество слов ");
        }

        [TestMethod()]
        public void Words_SymbolEngAndRus_NotWord()
        {
            string input = "DЛ";
            string[] strForSearch = { "А111ПЛ", "G121DD", "Л000ЖА", "Л765ЖK" };

            Words w = new Words(strForSearch, input);

            string expectedResult = "";
            int expectedQuantity = 0;

            string actualResult = w.Result;
            int actualQuantity = w.Quantity;

            Assert.AreEqual(expectedResult, actualResult, "Вывод слов на дисплей ");
            Assert.AreEqual(expectedQuantity, actualQuantity, "Количество слов ");
        }

        [TestMethod()]
        public void Words_NumSymbol_OneWord()
        {
            string input = "111";
            string[] strForSearch = { "А111ПЛ", "G121DD", "Л000ЖА", "Л765ЖK" };

            Words w = new Words(strForSearch, input);

            string expectedResult = "А111ПЛ";
            int expectedQuantity = 1;

            string actualResult = w.Result;
            int actualQuantity = w.Quantity;

            Assert.AreEqual(expectedResult, actualResult, "Вывод слов на дисплей ");
            Assert.AreEqual(expectedQuantity, actualQuantity, "Количество слов ");
        }

    }
}
