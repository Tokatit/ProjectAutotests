﻿using System.IO;
using App = System.AppDomain;

namespace NumberSearch
{
   public class ReadFile
    {
        public ReadFile()
        {
            string path = App.CurrentDomain.BaseDirectory + "Number.txt";

            Str = File.ReadAllLines(path, System.Text.Encoding.GetEncoding(1251));
        }

        public string [] Str { get; set; }
    }
}
