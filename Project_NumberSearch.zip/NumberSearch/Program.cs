﻿using System;

namespace NumberSearch
{
   public class Program
    {
        public static void Main()
        {
            Console.WriteLine("Введите полный или частичный номер машины");

            while (true)
            {
                var oneSymbol = Console.ReadKey();

                if (oneSymbol.Key == ConsoleKey.Escape)

                    break;

                string num = oneSymbol.KeyChar.ToString().ToUpper() + Console.ReadLine().ToUpper();

                ReadFile file = new ReadFile();

                string[] str = file.Str;

                Words result = new Words(str, num);

                GetResult(result);
            }
        }

        public static void GetResult (Words result)
        {
            if (result.Quantity != 0)
            {
                Console.WriteLine('\n' + "Количество записей: " + result.Quantity + '\n' + result.Result);
            }
            else
            {
                Console.WriteLine('\n' + "Такого номера нет в базе");
            }

            Console.WriteLine('\n' + "Если хотите выйти, нажмите ESC, иначе введите номер машины:");
        }
    }
}