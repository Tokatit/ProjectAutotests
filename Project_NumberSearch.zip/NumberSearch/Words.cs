﻿using System;
using System.Linq;

namespace NumberSearch
{
    public class Words
    {
        public Words(string[] str, string num)
        {
            string numCaseSensitivity = num.ToUpper();

            string[] lines = str.Where(l => l.Contains(num)).ToArray();

            Quantity = lines.Length;

            Result = string.Join(Environment.NewLine, lines);
        }

        public string Result { get; }

        public int Quantity { get; }
    }
}
